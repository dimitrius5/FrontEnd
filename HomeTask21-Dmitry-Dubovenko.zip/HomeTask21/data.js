'use strict';

const conversions = 
    {
        m: 1,
        mm: 0.001,
        cm: 0.01,

        in: 0.0254,
        ft: 0.3048,
    }