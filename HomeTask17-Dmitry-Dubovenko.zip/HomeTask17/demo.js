'use strict';

shop.goods = goods;
shop
    .showList()
    .showList('Процессоры')
    .showList('klsfkl2222')
    .addToCart('xcds')
    .addToCart('zg82')
    .addToCart('kio1')
    .removeFromCart('kio1')
    .addToCart('kio1')
    .addToCart('IVAN')
    .addToCart('')
    .showCart()
console.log(shop.cupit());
