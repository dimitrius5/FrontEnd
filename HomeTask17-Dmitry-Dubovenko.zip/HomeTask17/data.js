'use strict';

const goods = [
    {
        id: 'xcds', 
        category: 'Процессоры', 
        name: 'intel i7 w8', 
        price: 600,
    },
    {
        id: 'asd2', 
        category: 'Материнская плата', 
        name: 'Acer b450', 
        price: 200,
    },
    {
        id: 'zg82', 
        category: 'Процессоры', 
        name: 'AMD', 
        price: 900,
    },
    {
        id: '1tgy', 
        category: 'Одежда', 
        name: 'Радужные', 
        price: 2.22,
    },
    {
        id: 'n6ba', 
        category: 'Продукты', 
        name: 'Tomato', 
        price: 1.5,
    },
    {
        id: 'kio1', 
        category: 'Процессоры', 
        name: 'Rizen', 
        price: 780.5,
    },
    {
        id: 'IVAN', 
        category: 'Одежда', 
        name: 'Футболка розовая', 
        price: 40,
    },
]